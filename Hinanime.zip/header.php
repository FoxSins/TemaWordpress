<?php
/*

* Ini File Header.PHP
* Tema Ini Dibuat Oleh Pemula
* Github.com/FoxSins

*/
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php wp_title('_').' '.bloginfo('name'); ?></title>
    <link rel="stylesheet" type="text/css" href="<?php echo get_stylesheet_directory_uri(). '/style.css' ?>">
    <?php wp_head(); ?>
</head>
<body>
    <div class="wrapper">
        <div class="header">
            <div class="site-title">
                <h1><?php bloginfo('name'); ?></h1>
                <p><?php bloginfo('description'); ?></p>
            </div>
            
            
            <div class="navigation">
                <?php wp_nav_menu( array( 'theme_location' => 'menu-utama' ) ); ?>
            <div class="nav-search">
                <?php get_search_form() ;?>
            </div>
        </div>
    </div>

