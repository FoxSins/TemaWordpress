    </body>
    <div class="footer">
        <div class="copyright">
            &copy; Hinanime Powered By Wordpress
        </div>
     </div>
     <?php wp_footer(); ?>
</html>