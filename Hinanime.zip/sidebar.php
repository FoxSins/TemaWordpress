<?php if ( is_active_sidebar( 'sidebar-1' ) )  { ?>
    <div id="sidebar">
        <div class="inner_bar">
            <?php dynamic_sidebar( 'sidebar-1' ); ?>
        </div>
    </div>
<?php } else { ?>
    <div id="sidebar">
        <div class="inner_bar">
        <p align="center">Tambah Dulu Widgetnya</p>
        <p align="center">Tampilan > Widget > Sidebar Utama</p>
        </div>
    </div>
<?php } ?>