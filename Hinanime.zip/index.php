<?php
/*

* Ini File Index.PHP
* Tema Ini Dibuat Oleh Pemula
* Github.com/FoxSins

*/
get_header(); // Memanggil Header ?>

<div class="container">
    <div class="content">
        <div class="looping">
        <?php if ( have_posts() ) {
        //tampilkan daftar postingan
            while ( have_posts() ) { 
            the_post(); ?>
            <div class="loop-post">
                <div class="clear">
                <a href="<?php the_permalink(); ?>">
                    <?php if ( has_post_thumbnail() ) {
                    echo '<div class="post-thumb">';
                        the_post_thumbnail();
                    echo '</div>';
                    // Kode Thumbnail Buat Di Sebelum Judul
                    } ?>
                    <div class="meta">
                        <h2 class="title"><?php the_title(); ?></a></h2>
                    <div class="categories">
                        <?php the_category(''); ?>
                    </div>
                    <div class="date">
                        Rilis : <?php the_date(); ?>
                    </div>
                    </div>
                </div>
            </div>
    <?php }

    // Menampilkan Pagination
    ?>
    <div class="paggination">
    <div class="nav-next"><?php previous_posts_link( 'Older Post' ); ?></div>
    <div class="nav-prev"><?php next_posts_link( 'Newer Posts' ); ?></div>
    </div>

    <?php
    } else {
        echo 'Post Not Found!';
    }?>
    </div>
</div>


    <div class="sidebar">
        <?php get_sidebar(); ?>
    </div>
</div>


<?php
get_footer(); // Memanggil Footer
?>