<?php
/*

* Ini Functions.php

*/

function register_my_menu() {
    register_nav_menu('menu-utama',__( 'Menu Utama' ));
  }
  add_action( 'init', 'register_my_menu' );

  add_theme_support( 'post-thumbnails' );

/**
 * Tambah Sidebar / Widget.
 */
add_action ('widget_init','Hinanime_Sidebar');
function wpdocs_theme_slug_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Sidebar Utama', 'Hinanime' ),
        'id'            => 'sidebar-1',
        'description'   => __( 'Lokasi Sidebar / Widget Tema Hinanime.', 'Hinanime' ),
        'before_widget' => '<li id="%1$s" class="widget %2$s">',
        'after_widget'  => '</li>',
        'before_title'  => '<h2 class="widgettitle">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'wpdocs_theme_slug_widgets_init' );