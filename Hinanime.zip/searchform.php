<form action="/" method="get">
    <input type="text" name="s" id="search" value="<?php the_search_query(); ?>" />
    <input type="submit" value="Cari">
</form>